---
abstract: This collection holds roles that join K8S nodes to an existing cluster.
authors:
   - name: Xander Harris
     email: xandertheharris@gmail.com
date: 2024-07-24
title: Ansible Runtime
---

```{literalinclude} /edwardtheharris/k8s/meta/runtime.yml
```

<!--
```{autoyaml} edwardtheharris/k8s/meta/runtime.yml
```
-->

```{sectionauthor} Xander Harris <xandertheharris@gmail.com>
```
